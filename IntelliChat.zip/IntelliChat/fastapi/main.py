from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
import requests
from PyPDF2 import PdfReader
from docx import Document

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

document_text = ""

OPENROUTER_API_KEY = "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"


# ================= FILE UPLOAD =================

@app.post("/upload")

async def upload_file(file: UploadFile = File(...)):

    global document_text

    file_path = f"uploads/{file.filename}"

    with open(file_path, "wb") as f:

        f.write(await file.read())

    ext = file.filename.split(".")[-1].lower()



    # PDF

    if ext == "pdf":

        reader = PdfReader(file_path)

        text = ""

        for page in reader.pages:

            extracted = page.extract_text()

            if extracted:

                text += extracted

        document_text = text



    # DOCX

    elif ext == "docx":

        doc = Document(file_path)

        document_text = "\n".join(

            [p.text for p in doc.paragraphs]

        )



    # TXT

    elif ext == "txt":

        with open(

            file_path,

            "r",

            encoding="utf8"

        ) as f:

            document_text = f.read()



    else:

        document_text = "Unsupported file type"



    return {

        "message":
        "File uploaded successfully"

    }


# ================= CHAT API =================

@app.post("/chat")

async def chat(data: dict):

    try:

        message = data["message"]



        final_prompt = f"""

        Document Content:

        {document_text}



        User Question:

        {message}

        """



        response = requests.post(

            "https://openrouter.ai/api/v1/chat/completions",

            headers={

                "Authorization":
                f"Bearer {OPENROUTER_API_KEY}",

                "Content-Type":
                "application/json"

            },

            json={

                "model":
                "openai/gpt-3.5-turbo",

                "messages": [

                    {

                        "role": "user",

                        "content": final_prompt

                    }

                ]

            },

            timeout=30

        )



        result = response.json()

        print(result)



        if "choices" not in result:

            return {

                "reply":
                "OpenRouter API Error"

            }



        return {

            "reply":
            result["choices"][0]["message"]["content"]

        }



    except Exception as e:

        print(e)



        return {

            "reply":
            "Network/API Error"

        }