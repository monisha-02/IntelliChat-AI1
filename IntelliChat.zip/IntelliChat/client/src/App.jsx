import { useState, useEffect, useRef } from "react";
import axios from "axios";

function App() {

  const [isActive, setIsActive] = useState(false);

  const [isLoggedIn, setIsLoggedIn] =
    useState(false);

  const [name, setName] = useState("");

  const [email, setEmail] = useState("");

  const [password, setPassword] =
    useState("");

  const [message, setMessage] =
    useState("");

  const [uploadedFileName, setUploadedFileName] =
    useState("");

  const [isTyping, setIsTyping] =
    useState(false);

  const [messages, setMessages] =
    useState([
      {
        sender: "ai",
        text:
          "Hello! I'm IntelliChat AI",
        time:
          new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit"
          })
      }
    ]);

  const [chatHistory, setChatHistory] =
    useState([]);

  const [currentChatTitle, setCurrentChatTitle] =
    useState("New Chat");

  const [currentChatId, setCurrentChatId] =
    useState(null);

  const chatEndRef = useRef(null);



  // ================= AUTO SCROLL =================

  useEffect(() => {

    chatEndRef.current?.scrollIntoView({

      behavior: "smooth"

    });

  }, [messages, isTyping]);



  // ================= LOCAL STORAGE =================

  useEffect(() => {

    const savedChats =
      localStorage.getItem(
        "chatHistory"
      );



    if (savedChats) {

      setChatHistory(
        JSON.parse(savedChats)
      );

    }

  }, []);



  useEffect(() => {

    localStorage.setItem(

      "chatHistory",

      JSON.stringify(chatHistory)

    );

  }, [chatHistory]);



  // ================= SIGNUP =================

  const handleSignup = async () => {

    try {

      const res = await axios.post(

        "http://localhost:5000/api/auth/signup",

        {
          name,
          email,
          password
        }

      );



      alert(res.data.message);

      setIsActive(false);

    } catch (error) {

      alert(

        error.response?.data?.message ||

        "Signup Failed"

      );

    }

  };



  // ================= LOGIN =================

  const handleLogin = async () => {

    try {

      const res = await axios.post(

        "http://localhost:5000/api/auth/login",

        {
          email,
          password
        }

      );



      localStorage.setItem(

        "token",

        res.data.token

      );



      setIsLoggedIn(true);

    } catch (error) {

      alert(

        error.response?.data?.message ||

        "Login Failed"

      );

    }

  };



  // ================= NEW CHAT =================

  const createNewChat = () => {

    if (messages.length > 1) {

      const existingChat = {

        id: Date.now(),

        title:

          currentChatTitle !== "New Chat"

            ? currentChatTitle

            : uploadedFileName

            ? uploadedFileName.slice(0, 25)

            : messages[1]?.text?.slice(0, 25) ||

              "Untitled Chat",

        messages,

        uploadedFileName

      };



      setChatHistory((prev) => [

        existingChat,

        ...prev

      ]);

    }



    setMessages([
      {
        sender: "ai",
        text:
          "Hello! I'm IntelliChat AI",
        time:
          new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit"
          })
      }
    ]);



    setUploadedFileName("");



    setCurrentChatTitle(
      "New Chat"
    );



    setCurrentChatId(null);

  };



  // ================= SEND MESSAGE =================

  const sendMessage = async () => {

    if (!message.trim()) return;



    const onlyAiGreeting =
      messages.length === 1 &&
      messages[0].sender === "ai";



    if (
      onlyAiGreeting &&
      currentChatId === null
    ) {

      const cleanTitle =
        message.trim();

      const ignoredTitles = [

        "hi",

        "hello",

        "hey"

      ];



      if (

        !ignoredTitles.includes(

          cleanTitle.toLowerCase()

        )

      ) {

        setCurrentChatTitle(

          cleanTitle.slice(0, 25)

        );

      }

    }



    const userMessage = {

      sender: "user",

      text: message,

      time:
        new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit"
        })

    };



    setMessages((prev) => [

      ...prev,

      userMessage

    ]);



    const currentMessage = message;

    setMessage("");

    setIsTyping(true);



    try {

      const res = await axios.post(

        "http://127.0.0.1:8000/chat",

        {
          message: currentMessage
        }

      );



      const aiMessage = {

        sender: "ai",

        text:
          res.data.reply,

        time:
          new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit"
          })

      };



      setMessages((prev) => [

        ...prev,

        aiMessage

      ]);



    } catch (error) {

      console.log(error);

    } finally {

      setIsTyping(false);

    }

  };



  // ================= CHAT SCREEN =================

  if (isLoggedIn) {

    return (

      <div className="h-screen bg-gradient-to-br from-black via-zinc-950 to-zinc-900 text-white flex overflow-hidden">

        {/* SIDEBAR */}

        <div className="w-[300px] bg-black/40 backdrop-blur-xl border-r border-zinc-800 p-6 flex flex-col">

          {/* LOGO */}

          <div className="flex items-center gap-3 mb-10 px-2">

            <div className="w-10 h-10 rounded-xl bg-white text-black flex items-center justify-center text-lg font-black shadow-lg">

              ⬢

            </div>



            <div className="flex flex-col">

              <span className="text-[17px] font-semibold leading-none">

                IntelliChat

              </span>

              <span className="text-xs text-zinc-500 mt-1">

                AI Assistant

              </span>

            </div>

          </div>



          {/* NEW CHAT BUTTON */}

          <button

            onClick={createNewChat}

            className="bg-white text-black py-4 rounded-2xl font-semibold mb-6 hover:scale-[1.02] hover:bg-gray-200 transition-all duration-300 shadow-lg"
          >

            + New Chat

          </button>



          {/* CHAT HISTORY */}

          <div className="flex-1 overflow-y-auto space-y-3 pr-2">

            {
              chatHistory.length === 0 ? (

                <div className="text-zinc-500 text-sm mt-6">

                  Start a new conversation

                </div>

              ) : (

                chatHistory.map((chat) => (

                  <div
                    key={chat.id}

                    onClick={() => {

                      setMessages(
                        chat.messages
                      );



                      setUploadedFileName(
                        chat.uploadedFileName
                      );



                      setCurrentChatTitle(
                        chat.title
                      );



                      setCurrentChatId(
                        chat.id
                      );

                    }}

                    className={`p-4 rounded-2xl cursor-pointer transition-all duration-300 break-words border ${
                      currentChatId === chat.id
                        ? "bg-white text-black border-white shadow-xl"
                        : "bg-zinc-900/70 border-zinc-800 hover:bg-zinc-800 hover:scale-[1.02]"
                    }`}
                  >

                    {chat.title}

                  </div>

                ))

              )
            }

          </div>



          {/* LOGOUT */}

          <button
            onClick={() => {

              localStorage.removeItem("token");

              setIsLoggedIn(false);

            }}
            className="mt-6 border border-zinc-700 py-4 rounded-2xl hover:bg-zinc-900 transition-all"
          >

            Logout

          </button>

        </div>



        {/* MAIN CHAT */}

        <div className="flex-1 flex flex-col">

          {/* HEADER */}

          <div className="h-[80px] border-b border-zinc-800 flex items-center px-8 text-2xl font-semibold bg-black/20 backdrop-blur-lg">

            IntelliChat

          </div>



          {/* CHAT AREA */}

          <div className="flex-1 overflow-y-auto p-8 space-y-8">

            {
              messages.map((msg, index) => (

                <div
                  key={index}
                  className={`flex ${
                    msg.sender === "user"
                      ? "justify-end"
                      : "justify-start"
                  }`}
                >

                  <div className="flex gap-3 max-w-[70%]">

                    {/* AI AVATAR */}

                    {
                      msg.sender === "ai" && (

                        <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-sm font-bold">

                          AI

                        </div>

                      )
                    }



                    <div>

                      <div
                        className={`px-6 py-4 rounded-3xl break-words shadow-lg ${
                          msg.sender === "user"
                            ? "bg-white text-black"
                            : "bg-zinc-900 border border-zinc-700 text-white"
                        }`}
                      >

                        {msg.text}

                      </div>



                      <div className="text-xs text-zinc-500 mt-2 px-2">

                        {msg.time}

                      </div>

                    </div>



                    {/* USER AVATAR */}

                    {
                      msg.sender === "user" && (

                        <div className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center text-sm font-bold">

                          U

                        </div>

                      )
                    }

                  </div>

                </div>

              ))
            }



            {/* TYPING */}

            {
              isTyping && (

                <div className="flex items-center gap-3">

                  <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-sm font-bold">

                    AI

                  </div>



                  <div className="bg-zinc-900 border border-zinc-700 px-6 py-4 rounded-3xl animate-pulse">

                    Generating...

                  </div>

                </div>

              )
            }



            <div ref={chatEndRef}></div>

          </div>



          {/* INPUT AREA */}

          <div className="p-6 border-t border-zinc-800 flex gap-4 items-center relative bg-black/20 backdrop-blur-lg">

            {/* PLUS BUTTON */}

            <div className="relative">

              <button
                onClick={() =>
                  document
                    .getElementById("fileInput")
                    .click()
                }
                className="w-14 h-14 bg-zinc-900 border border-zinc-800 rounded-2xl text-3xl hover:bg-zinc-800 transition-all"
              >

                +

              </button>



              <input
                id="fileInput"
                type="file"
                hidden
                accept=".pdf,.txt,.docx"

                onChange={async (e) => {

                  const selectedFile =
                    e.target.files[0];



                  if (!selectedFile) return;



                  setUploadedFileName(
                    selectedFile.name
                  );



                  const formData =
                    new FormData();

                  formData.append(
                    "file",
                    selectedFile
                  );



                  try {

                    await axios.post(

                      "http://127.0.0.1:8000/upload",

                      formData,

                      {

                        headers: {

                          "Content-Type":
                            "multipart/form-data"

                        }

                      }

                    );



                    const fileMessage = {

                      sender: "user",

                      text:
                        selectedFile.name,

                      time:
                        new Date().toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit"
                        })

                    };



                    setMessages((prev) => [

                      ...prev,

                      fileMessage

                    ]);



                    if (
                      currentChatTitle ===
                      "New Chat"
                    ) {

                      setCurrentChatTitle(

                        selectedFile.name.slice(
                          0,
                          25
                        )

                      );

                    }



                  } catch (error) {

                    console.log(error);

                    alert("Upload failed");

                  }

                }}
              />

            </div>



            {/* MESSAGE INPUT */}

            <textarea
              rows={1}
              placeholder="Ask anything..."
              value={message}
              onChange={(e) =>
                setMessage(e.target.value)
              }

              onKeyDown={(e) => {

                if (
                  e.key === "Enter" &&
                  !e.shiftKey
                ) {

                  e.preventDefault();

                  sendMessage();

                }

              }}

              style={{
                resize: "none",
                maxHeight: "200px"
              }}

              className="flex-1 bg-zinc-950 border border-zinc-800 focus:border-zinc-600 p-4 rounded-2xl outline-none text-white transition-all"
            />



            {/* SEND BUTTON */}

            <button
              onClick={sendMessage}
              className="bg-white text-black px-8 h-14 rounded-2xl font-semibold hover:bg-gray-200 hover:scale-[1.03] transition-all duration-300 shadow-lg"
            >

              Send

            </button>

          </div>

        </div>

      </div>

    );

  }



  // ================= LOGIN / SIGNUP =================

  return (

    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-black via-zinc-950 to-zinc-900 overflow-hidden px-4">

      <div className="relative w-[950px] h-[600px] bg-white/5 backdrop-blur-2xl border border-zinc-800 rounded-[40px] shadow-2xl overflow-hidden">

        {/* LOGIN */}

        <div className={`absolute top-0 left-0 w-1/2 h-full flex items-center justify-center transition-all duration-700 z-20
        ${isActive ? "-translate-x-full opacity-0" : "translate-x-0 opacity-100"}`}>

          <div className="w-[75%]">

            <h1 className="text-5xl text-white font-bold mb-3">

              Welcome Back

            </h1>



            <p className="text-zinc-400 mb-8">

              Login to continue your AI journey

            </p>



            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) =>
                setEmail(e.target.value)
              }
              className="w-full bg-zinc-900 border border-zinc-800 text-white p-4 mb-4 rounded-2xl outline-none"
            />



            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) =>
                setPassword(e.target.value)
              }
              className="w-full bg-zinc-900 border border-zinc-800 text-white p-4 mb-6 rounded-2xl outline-none"
            />



            <button
              onClick={handleLogin}
              className="w-full bg-white text-black py-4 rounded-2xl hover:bg-gray-200 transition-all font-semibold"
            >

              Login

            </button>

          </div>

        </div>



        {/* SIGNUP */}

        <div className={`absolute top-0 right-0 w-1/2 h-full flex items-center justify-center transition-all duration-700 z-20
        ${isActive ? "translate-x-0 opacity-100" : "translate-x-full opacity-0"}`}>

          <div className="w-[75%]">

            <h1 className="text-5xl text-white font-bold mb-3">

              Create Account

            </h1>



            <p className="text-zinc-400 mb-8">

              Join the future of AI conversations

            </p>



            <input
              type="text"
              placeholder="Full Name"
              value={name}
              onChange={(e) =>
                setName(e.target.value)
              }
              className="w-full bg-zinc-900 border border-zinc-800 text-white p-4 mb-4 rounded-2xl outline-none"
            />



            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) =>
                setEmail(e.target.value)
              }
              className="w-full bg-zinc-900 border border-zinc-800 text-white p-4 mb-4 rounded-2xl outline-none"
            />



            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) =>
                setPassword(e.target.value)
              }
              className="w-full bg-zinc-900 border border-zinc-800 text-white p-4 mb-6 rounded-2xl outline-none"
            />



            <button
              onClick={handleSignup}
              className="w-full bg-white text-black py-4 rounded-2xl hover:bg-gray-200 transition-all font-semibold"
            >

              Sign Up

            </button>

          </div>

        </div>



        {/* SLIDING PANEL */}

        <div className={`absolute top-0 left-1/2 w-1/2 h-full bg-gradient-to-br from-zinc-900 via-black to-zinc-950 text-white flex flex-col items-center justify-center text-center px-10 transition-all duration-700 z-30
        ${isActive ? "-translate-x-full rounded-r-[120px]" : "translate-x-0 rounded-l-[120px]"}`}>

          {
            isActive ? (
              <>
                <h1 className="text-5xl font-bold mb-4">

                  Welcome Back!

                </h1>

                <p className="mb-8 text-lg text-zinc-400">

                  Already have an account?

                </p>

                <button
                  onClick={() =>
                    setIsActive(false)
                  }
                  className="border border-white px-8 py-3 rounded-full hover:bg-white hover:text-black transition-all"
                >

                  Login

                </button>
              </>
            ) : (
              <>
                <h1 className="text-5xl font-bold mb-4">

                  Hello Friend!

                </h1>

                <p className="mb-8 text-lg text-zinc-400">

                  Create account to explore AI

                </p>

                <button
                  onClick={() =>
                    setIsActive(true)
                  }
                  className="border border-white px-8 py-3 rounded-full hover:bg-white hover:text-black transition-all"
                >

                  Sign Up

                </button>
              </>
            )
          }

        </div>

      </div>

    </div>

  );

}

export default App;