const express = require("express");

const router = express.Router();

const multer = require("multer");

const fs = require("fs");

const pdfParse = require("pdf-parse");

const mammoth = require("mammoth");

const axios = require("axios");



let documentText = "";



// STORAGE

const storage = multer.diskStorage({

  destination: (req, file, cb) => {

    cb(null, "uploads/");

  },



  filename: (req, file, cb) => {

    cb(

      null,

      Date.now() +
      "-" +
      file.originalname

    );

  }

});



const upload = multer({

  storage

});



// UPLOAD ROUTE

router.post(

  "/upload",

  upload.single("file"),

  async (req, res) => {

    try {

      if (!req.file) {

        return res.status(400).json({

          message:
            "No file uploaded"

        });

      }



      const filePath =
        req.file.path;

      const ext =
        req.file.originalname
          .split(".")
          .pop()
          .toLowerCase();



      // PDF

      if (ext === "pdf") {

        const dataBuffer =
          fs.readFileSync(filePath);

        const pdfData =
          await pdfParse(dataBuffer);

        documentText =
          pdfData.text;

      }



      // DOCX

      else if (ext === "docx") {

        const result =
          await mammoth.extractRawText({

            path: filePath

          });

        documentText =
          result.value;

      }



      // TXT

      else if (ext === "txt") {

        documentText =
          fs.readFileSync(

            filePath,

            "utf8"

          );

      }



      // OTHER FILES

      else {

        documentText =
          "Unsupported file type content";

      }



      res.json({

        message:
          "File uploaded successfully"

      });

    } catch (error) {

      console.log(error);



      res.status(500).json({

        message:
          "Upload failed"

      });

    }

  }

);



// AI CHAT

router.post("/", async (req, res) => {

  try {

    const { message } = req.body;



    const finalPrompt =

      documentText

        ? `Document Content:\n${documentText}\n\nUser Question:\n${message}`

        : message;



    const response =
      await axios.post(

        "https://openrouter.ai/api/v1/chat/completions",

        {

          model:
            "openai/gpt-3.5-turbo",

          messages: [

            {

              role: "user",

              content:
                finalPrompt

            }

          ]

        },

        {

          headers: {

            Authorization:
              `Bearer ${process.env.OPENROUTER_API_KEY}`,

            "Content-Type":
              "application/json"

          }

        }

      );



    res.json({

      reply:
        response.data
          .choices[0]
          .message.content

    });

  } catch (error) {

    console.log(error);



    res.status(500).json({

      reply:
        "AI Error"

    });

  }

});



module.exports = router;